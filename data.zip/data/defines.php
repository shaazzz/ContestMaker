<?php
define("CODEFORCES_USERNAME", "shaazzz_admin");
define("CODEFORCES_PASSWORD", "inPasswordShaazzzAst");
define("CODEFORCES_API_KEY", "74549d19b172095859d90d556499fa9c6c45db3f");
define("CODEFORCES_API_SECRET", "6528f3887d3dbd195c8a85bdf38f4d54f37a8017");
define("TELEGRAM_API", "1251006003:AAGpw8gi5LTN5QAdlS1nLMegxgHjl6zuR5A");
define("TELEGRAM_CHANNEL_ID", "@CodeforcesMashup");
define("TELEGRAM_SCOREBOARD_CAPTION", "نفرات اول این هفته🥳");
define("IMG_PWD","0b429c7a-a620-44bc-aff8-773fa0f3e14d" . ":" . "059cce1c-d69d-4ff6-bb0c-739c4ce468b7");
define("CONTEST_LEVEL0", "Beginners");
define("CONTEST_LEVEL1", "Specialist");
define("CONTEST_LEVEL2", "Candidate masters");
define("CONTEST_LEVEL3", "Grandmasters");
define("CF_GROUP_PREFIX_ADDRESS", "group/tFEA7pkTiD/contest");