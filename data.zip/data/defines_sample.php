<?php

// codeforces default username
define("CODEFORCES_USERNAME", "...");
// codeforces default password
define("CODEFORCES_PASSWORD", "...");

// codeforces api key
define("CODEFORCES_API_KEY", "...");
// codeforces api secret
define("CODEFORCES_API_SECRET", "...");

// telegram api token
define("TELEGRAM_API", "...");
// telegram channel id
define("TELEGRAM_CHANNEL_ID", "...");
// https://hcti.io token
define("IMG_PWD", "..." . ":" . "...");
// codeforces group token
define("CF_GROUP_ID", "...");

define("CONTEST_LEVEL0", "Beginners");
define("CONTEST_LEVEL1", "Specialists");
define("CONTEST_LEVEL2", "Candidate masters");
define("CONTEST_LEVEL3", "Grandmasters");
define("TELEGRAM_SCOREBOARD_CAPTION", "نفرات اول این هفته🥳");
define("CF_GROUP_PREFIX_ADDRESS", "group/" . CF_GROUP_ID . "/contest");
define("MAXIMUM_BACKUP_FILES", 10);
define("TIMER_UPDATE_EVERY_DAY", true);
